# Hospital-Management-System
This is a simple and fully functional hospital management system application created by using react and vite 
