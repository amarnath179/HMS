package com.example.demo.entity;

public class Problems {

	private Long id;
	private String problemName;
	private String problemDetails;
	
	
}
