package com.example.demo.entity.enums;

public enum ProblemStatus {
	AYAKTA,
	YATILIK,
	ACİL,
	AMELİYATHANE,
	YOĞUN_BAKIM
}
