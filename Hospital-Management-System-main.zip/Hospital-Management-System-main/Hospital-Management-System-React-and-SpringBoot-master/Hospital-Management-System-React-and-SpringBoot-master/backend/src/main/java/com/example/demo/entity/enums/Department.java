package com.example.demo.entity.enums;

public enum Department {
	BRAIN_SURGEON,
	DENTIST,
	DERMATOLOGY,
	HEART_SURGEON,
	EAR_NOSE_THROAT,
	GENERAL_SURGEON,
	NUTRITIONIST,
	PLASTIC_SURGERY,
}
