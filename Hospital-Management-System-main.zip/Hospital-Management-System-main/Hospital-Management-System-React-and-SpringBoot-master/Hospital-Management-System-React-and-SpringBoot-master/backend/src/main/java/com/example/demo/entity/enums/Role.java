package com.example.demo.entity.enums;

public enum Role {
    USER, ADMIN
}
