package com.example.demo.entity;

public enum ProblemStatus {
	AYAKTA,
	YATILIK,
	ACİL,
	AMELİYATHANE,
	YOĞUN_BAKIM
}
